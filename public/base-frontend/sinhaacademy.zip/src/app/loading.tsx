import React from 'react';

import { SuspenseLoader } from '@/components/App/Loader';

function Loading() {
  return <SuspenseLoader />;
}

export default Loading;
