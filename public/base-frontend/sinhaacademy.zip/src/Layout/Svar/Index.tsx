'use client';

import React, { useState } from 'react';
import { Container } from 'react-bootstrap';

import styles from '@/styles/Components/Container/Svar.module.scss';

const swaraMap = [
  { name: 'अ', audioUrl: '/assets/mp3/swara/अ.mp3' },
  { name: 'आ', audioUrl: '/assets/mp3/swara/आ.mp3' },
  { name: 'इ', audioUrl: '/assets/mp3/swara/इ.mp3' },
  { name: 'ई', audioUrl: '/assets/mp3/swara/ई.mp3' },
  { name: 'उ', audioUrl: '/assets/mp3/swara/उ.mp3' },
  { name: 'ऊ', audioUrl: '/assets/mp3/swara/ऊ.mp3' },
  { name: 'ऋ', audioUrl: '/assets/mp3/swara/ऋ.mp3' },
  { name: 'ए', audioUrl: '/assets/mp3/swara/ए.mp3' },
  { name: 'ऐ', audioUrl: '/assets/mp3/swara/ऐ.mp3' },
  { name: 'ओ', audioUrl: '/assets/mp3/swara/ओ.mp3' },
  { name: 'औ', audioUrl: '/assets/mp3/swara/औ.mp3' },
  { name: 'अं', audioUrl: '/assets/mp3/swara/अं.mp3' },
  { name: 'अः', audioUrl: '/assets/mp3/swara/अः.mp3' },
];

function Index() {
  const [selectedValue, setSeletedValue] = useState<string>('');
  const BaloonImg = '/assets/images/yellow_baloon.png';

  // Function to handle play audio on click
  const handlePlayAudio = (audioUrl: string, name: string) => {
    setSeletedValue(name);
    const audio = new Audio(audioUrl);
    audio.play();
  };

  return (
    <>
      <div className={styles.LearningPage}>
        <div className={styles.LearningWrap}>
          <Container>
            <div className={styles.baloonTitle}>
              <h2>स्वर - Pop all the 12 balloons! 🤪 🎈 🎊</h2>
            </div>
            <div className={styles.baloonGroup}>
              {swaraMap.map((item: any, index: number) => (
                <div key={index} className={`${selectedValue === item.name ? 'active' : ''} ${styles.SingleBaloon}`}>
                  <div className={styles.BaloonImg}>
                    <img src={BaloonImg} alt="Balloon" />
                  </div>
                  <div className={styles.SvarWrap}>
                    <h5 onClick={() => handlePlayAudio(item.audioUrl, item.name)} style={{ cursor: 'pointer' }}>
                      {item.name}
                    </h5>
                  </div>
                </div>
              ))}
            </div>
          </Container>
        </div>
      </div>
    </>
  );
}

export default Index;
